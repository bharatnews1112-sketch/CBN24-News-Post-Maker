package com.cbn24.newspostmaker;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends android.app.Activity {
    EditText headline, story, reporter, location;
    ImageView selectedPhoto, posterPreview;
    Bitmap photoBitmap, posterBitmap, logoBitmap;
    static final int PICK_IMAGE = 101;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView label(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(4), dp(6), dp(4), dp(4));
        return t;
    }

    EditText edit(String hint, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setBackgroundColor(Color.WHITE);
        if (minLines > 1) { e.setMinLines(minLines); e.setSingleLine(false); }
        else e.setSingleLine(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, minLines > 1 ? dp(170) : dp(55));
        p.setMargins(0, dp(4), 0, dp(8));
        e.setLayoutParams(p);
        return e;
    }

    Button btn(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(color);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(13,71,161));

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(20));
        root.setBackgroundColor(Color.rgb(245,245,245));
        scroll.addView(root);

        ImageView logoView = new ImageView(this);
        logoView.setImageResource(com.cbn24.newspostmaker.R.drawable.cbn24_logo);
        logoView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(logoView, new LinearLayout.LayoutParams(-1, dp(115)));

        TextView title = label("CBN 24 NEWS POST MAKER", 22);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.rgb(13,71,161));
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        headline = edit("मुख्य शीर्षक / Headline", 1);
        root.addView(headline);

        story = edit("समाचार का पूरा विवरण लिखें...", 7);
        root.addView(story);

        selectedPhoto = new ImageView(this);
        selectedPhoto.setImageResource(android.R.drawable.ic_menu_gallery);
        selectedPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        selectedPhoto.setBackgroundColor(Color.LTGRAY);
        root.addView(selectedPhoto, new LinearLayout.LayoutParams(-1, dp(220)));

        Button choose = btn("📷  फोटो चुनें", Color.rgb(21,101,192));
        root.addView(choose);

        reporter = edit("संवाददाता / Reporter", 1);
        root.addView(reporter);

        location = edit("स्थान / Location", 1);
        root.addView(location);

        TextView size = label("Story Size: 1080 × 1920", 15);
        size.setGravity(Gravity.CENTER);
        root.addView(size);

        Button make = btn("📰  पोस्ट तैयार करें", Color.rgb(21,101,192));
        root.addView(make);

        Button save = btn("💾  Save Image", Color.rgb(230,55,85));
        root.addView(save);

        Button share = btn("📤  Share", Color.rgb(21,101,192));
        root.addView(share);

        posterPreview = new ImageView(this);
        posterPreview.setAdjustViewBounds(true);
        posterPreview.setVisibility(View.GONE);
        root.addView(posterPreview, new LinearLayout.LayoutParams(-1, dp(620)));

        setContentView(scroll);

        choose.setOnClickListener(v -> pickImage());
        make.setOnClickListener(v -> {
            posterBitmap = makePoster();
            posterPreview.setImageBitmap(posterBitmap);
            posterPreview.setVisibility(View.VISIBLE);
            Toast.makeText(this, "पोस्ट तैयार हो गई", Toast.LENGTH_SHORT).show();
        });
        save.setOnClickListener(v -> {
            if (posterBitmap == null) posterBitmap = makePoster();
            savePoster(posterBitmap);
        });
        share.setOnClickListener(v -> {
            if (posterBitmap == null) posterBitmap = makePoster();
            sharePoster(posterBitmap);
        });
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            try {
                Uri u = data.getData();
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                photoBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(u));
                selectedPhoto.setImageBitmap(photoBitmap);
            } catch (Exception e) {
                Toast.makeText(this, "फोटो नहीं खुल सकी", Toast.LENGTH_SHORT).show();
            }
        }
    }

    Bitmap makePoster() {
        final int W = 1080, H = 1920;
        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));

        // Header
        Bitmap lg = BitmapFactory.decodeResource(getResources(), R.drawable.cbn24_logo);
        Rect dst = new Rect(35, 30, W-35, 300);
        c.drawBitmap(lg, null, dst, p);

        p.setColor(Color.rgb(13,71,161)); p.setStyle(Paint.Style.FILL);
        c.drawRect(35, 315, W-35, 318, p);

        String h = headline.getText().toString().trim();
        if (h.isEmpty()) h = "मुख्य शीर्षक / Headline";
        p.setColor(Color.rgb(20,20,20)); p.setTextSize(58); p.setTypeface(Typeface.DEFAULT_BOLD);
        drawWrapped(c, h, 55, 395, 970, p, 70, 3);

        int photoTop = 555;
        if (photoBitmap != null) {
            RectF pr = fitRect(photoBitmap, 40, photoTop, 1040, photoTop+570);
            c.drawBitmap(photoBitmap, null, pr, p);
        } else {
            p.setColor(Color.rgb(235,235,235)); c.drawRect(40, photoTop, 1040, photoTop+570, p);
            p.setColor(Color.GRAY); p.setTextSize(34); p.setTypeface(Typeface.DEFAULT);
            centerText(c, "फोटो चुनें", 540, photoTop+300, p);
        }

        int y = 1180;
        p.setColor(Color.rgb(13,71,161)); c.drawRect(40, y-55, 1040, y-50, p);
        p.setColor(Color.rgb(30,30,30)); p.setTextSize(38); p.setTypeface(Typeface.DEFAULT);
        String s = story.getText().toString().trim();
        if (s.isEmpty()) s = "समाचार का पूरा विवरण लिखें...";
        y = drawWrapped(c, s, 55, y, 970, p, 52, 9);

        p.setTextSize(32); p.setTypeface(Typeface.DEFAULT_BOLD);
        String r = reporter.getText().toString().trim();
        String loc = location.getText().toString().trim();
        if (!r.isEmpty()) { c.drawText("संवाददाता: " + r, 55, 1700, p); }
        if (!loc.isEmpty()) { c.drawText("स्थान: " + loc, 55, 1750, p); }

        p.setTypeface(Typeface.DEFAULT); p.setTextSize(28); p.setColor(Color.DKGRAY);
        c.drawText("CBN 24 News Post Maker", 55, 1840, p);
        c.drawText("www.citybreakingnews24.online", 55, 1885, p);
        return out;
    }

    RectF fitRect(Bitmap b, int l, int t, int r, int bot) {
        float boxW=r-l, boxH=bot-t, scale=Math.max(boxW/b.getWidth(), boxH/b.getHeight());
        float w=b.getWidth()*scale, h=b.getHeight()*scale;
        float x=l+(boxW-w)/2, y=t+(boxH-h)/2;
        return new RectF(x,y,x+w,y+h);
    }

    int drawWrapped(Canvas c, String text, float x, float y, float maxW, Paint p, float lineH, int maxLines) {
        String[] words=text.split("\\s+"); String line=""; int lines=0;
        for (String word:words) {
            String test=line.isEmpty()?word:line+" "+word;
            if (p.measureText(test)>maxW && !line.isEmpty()) {
                c.drawText(line,x,y,p); y+=lineH; lines++;
                if(lines>=maxLines) return (int)y;
                line=word;
            } else line=test;
        }
        if(!line.isEmpty() && lines<maxLines){c.drawText(line,x,y,p); y+=lineH;}
        return (int)y;
    }

    void centerText(Canvas c,String s,float x,float y,Paint p){ c.drawText(s,x-p.measureText(s)/2,y,p); }

    void savePoster(Bitmap b) {
        try {
            ContentValues v=new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME,"CBN24_"+System.currentTimeMillis()+".png");
            v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/CBN24");
            Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream os=getContentResolver().openOutputStream(u);
            b.compress(Bitmap.CompressFormat.PNG,100,os); os.close();
            Toast.makeText(this,"Image saved in Pictures/CBN24",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Save failed",Toast.LENGTH_LONG).show();}
    }

    void sharePoster(Bitmap b) {
        try {
            File f=new File(getCacheDir(),"cbn24_share.png");
            FileOutputStream os=new FileOutputStream(f); b.compress(Bitmap.CompressFormat.PNG,100,os); os.close();
            Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("image/png"); i.putExtra(Intent.EXTRA_STREAM,u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"Share CBN 24 Poster"));
        }catch(Exception e){Toast.makeText(this,"Share failed",Toast.LENGTH_LONG).show();}
    }
}
