# CBN 24 News Post Maker

A simple Android news-poster maker built for CBN 24.

Features:
- Headline and story entry
- Gallery photo picker
- Reporter and location fields
- 1080x1920 poster generation
- Save to Pictures/CBN24
- Share poster

## Build in AIDE / Android Studio
1. Extract this ZIP.
2. Open the folder as an Android/Gradle project.
3. Let Gradle sync.
4. Build > APK.
5. Install the generated APK on the phone.

The project uses native Android views and AndroidX Core only; no Firebase or paid service is required.
